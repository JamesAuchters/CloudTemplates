# Examples

This will help to understand how to setup certain scenarios with
xActiveDirectory resource module.

## Resource examples

These are the links to the examples for each individual resource.

- [xADObjectPermissionEntry](/Examples/Resources/xADObjectPermissionEntry)
- [xADUser](/Examples/Resources/xADUser)
